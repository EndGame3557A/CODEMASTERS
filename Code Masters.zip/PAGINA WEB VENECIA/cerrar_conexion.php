<?php
if (isset($conexion)) {
    $conexion->close();
}



if (isset($conn)) {
    $conn->close();
}
?>
